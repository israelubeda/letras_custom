# Libreria transformadora de texto

_Una libreria que transforma una letra por otra , ejemplo la letra A ,se transforma en letra Z_


## Comenzando 🚀

_instalar la libreria_

~~~
pip install letras-custom-israelubeda
~~~

*Modo de uso

Ejemplo:

example.py
~~~
from letras_custom_israelubeda import sustituir_letras

palabra = sustituir_letras("hola mundo")
print(palabra)

~~~

output: sooz nunwo



